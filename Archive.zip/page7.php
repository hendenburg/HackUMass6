<html>
<head>
    <link rel="stylesheet" href="../hero.css">
    <link rel="stylesheet" href="https://use.typekit.net/uef6xit.css">
    <link rel="stylesheet" href="page2.css">
</head>
<body>
    <div id="background1"></div>
    <div id="header">
        <a href="index.php">
            <img id="headerimage" src="../images/GameTimeLight.png" href="index.html" align="middle">
        </a>
    </div>
</body>
</html>