<html>
<head>
    <link rel="stylesheet" href="../hero.css">
    <link rel="stylesheet" href="https://use.typekit.net/uef6xit.css">
    <link rel="stylesheet" href="page2.css">
</head>
<body>
    <div id="background1"></div>
    <div id="header">
        <a href="index.php">
            <img id="headerimage" src="../images/GameTimeLight.png" href="index.html" align="middle">
        </a>
    </div>
    
    <span id="steps">
    <center><h2>Step 1 of 4</h2></center>
    </span>
    
    <div>
        <center><h2 id="subheader">Welcome to GameTime. We’ve got a couple questions for you, this will train our system to your tastes as a gamer.<br><br><strong>Which of these sentences best describes you ?</strong></h2></center>
    </div>
    <br>
    <br>
    <div>
        <center><a href="page3.php" color="white" id="button">I’ll play whatever, whenever!</a></center>
    </div>
    <br>
    <br>
    <br>
    <br>
    <div>
        <center><a href="page3.php" color="white" id="button">I like playing when I can find the time.</a></center>
        </div>
    <br>
    <br>
    <br>
    <br>
    <div>
        <center><a href="page3.php" color="white" id="button">I'll play a good game if it's recommended to me.</a></center>
        </div>
    <br>
    <br>
    <br>
    <br>
</body>
</html>