<html>
<head>
    <link rel="stylesheet" href="../hero.css">
    <link rel="stylesheet" href="https://use.typekit.net/uef6xit.css">
    <link rel="stylesheet" href="page3.css">
</head>
&nbsp&nbsp<body>
    <div id="background1"></div>
    <div id="header">
        <a href="index.php">
            <img id="headerimage" src="../images/GameTimeLight.png" href="index.html" align="middle">
        </a>
    </div>
    
    <span id="steps">
    <center><h2>Step 4 of 4</h2></center>
    </span>
    
    <div>
        <center><h2 id="subheader">Last but not least.<br><br><strong>What are your 3 most favorite games to play?</strong><br><br>1.&nbsp<input type="text" name="FirstGame" value=""><br>
        <form action="page6.php" method="post">
        2. <input type="text" name="SecondGame" value=""><br>
        3. <input type="text" name="ThirdGame" value=""><br>
    <br>
    <br>
    <div>
        <center><input id="button"type="submit"></center>
        </form>
    </div>
</body>
</html>