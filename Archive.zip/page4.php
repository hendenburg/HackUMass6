<html>
<head>
    <link rel="stylesheet" href="../hero.css">
    <link rel="stylesheet" href="https://use.typekit.net/uef6xit.css">
    <link rel="stylesheet" href="page3.css">
</head>
<body>
    <div id="background1"></div>
    <div id="header">
        <a href="index.php">
            <img id="headerimage" src="../images/GameTimeLight.png" href="index.html" align="middle">
        </a>
    </div>
    
    <span id="steps">
    <center><h2>Step 3 of 4</h2></center>
    </span>
    
    <div>
        <center><h2 id="subheader">Awesome! Now we’re going to ask just a few questions about genre.<br><br><strong>What genre's do you enjoy most?</strong></h2>

</strong></h2></center>
    <div><center>
        1. <input type="text" firstgame="FirstName" value=""><br><br>
        2. <input type="text" secondgame="FirstName" value=""><br><br>
        3. <input type="text" thirdgame="FirstName" value=""><br></center>
    <br>
    <br>
    <br>
    <br>
    <div>
        <center><a href="page5.php" color="white" id="button">Continue</a></center>
    </div>
</body>
</html>