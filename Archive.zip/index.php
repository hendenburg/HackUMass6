<html>
<head>
    <link rel="stylesheet" href="hero.css">
    <link rel="stylesheet" href="https://use.typekit.net/uef6xit.css">
</head>
<body>
    <br><br>
    <div id="background1"></div>
    <span id="hero">
        <center><h1>Welcome to <img id="mainlogoimage" src="images/GameTimeLightCircle.png" width="600" height="200" align="middle"></h1></center>
    </span>
    <span id="pg1subline">
        <center><h2>The smart video game search engine that works for you.</h2></center>
    </span>
    <br>
    <br>
    <br>
    <br>
    <div>
        <center><a href="page2.php" color="white" id="button1">Let's try it out</a></center>
    </div>
</body>
</html>