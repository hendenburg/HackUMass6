<html>
<head>
    <link rel="stylesheet" href="../hero.css">
    <link rel="stylesheet" href="https://use.typekit.net/uef6xit.css">
    <link rel="stylesheet" href="page3.css">
</head>
&nbsp&nbsp<body>
    <div id="background1"></div>
    <div id="header">
        <a href="index.php">
            <img id="headerimage" src="../images/GameTimeLight.png" href="index.html" align="middle">
        </a>
    </div>
    
    <span id="steps">
    <center><h2>Step 2 of 4</h2></center>
    </span>
    
    <div>
        <center><h2 id="subheader">Our system matches you to games that fit your schedule. Play in short sessions? We’ll find you games you can pick up and play.<br><br><strong>How many hours do you game each week?</strong><br><br></h2></center>  
    </div>
    <div>
        <center><input type="text" sun="FirstName" value=""></center>
    </div>
    <br>
    <br>
    <br>
    <br>
    <div>
        <center><a href="page4.php" color="white" id="button">Continue</a></center>
    </div>
</body>
</html>