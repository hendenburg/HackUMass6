<?php

$servername = "GameTime";
$igdb_api = "a3a100cec5fd39c002aad011e85d2dea"
$username = "root";
$password = "password";
$dbname = "gt_db";

?>